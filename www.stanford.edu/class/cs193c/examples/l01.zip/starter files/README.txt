You can use any one of these starter files for class assignments.

Unless you already have a particular preference, I recommend using HTML5 and beginning your work with the starter-html5.html file.

Note that the starter-html.html file will display a validation error on closing BODY element until you add elements between the <body> start and </body> end tag.