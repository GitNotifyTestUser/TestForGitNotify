// from Danny Goodman's Dynamic HTML

function myFunction(evt) {
    evt = (evt) ? evt : ((event) ? event : null);
    ...
}

