function convertKmToMiles(km) {
  return km * 0.62;
}