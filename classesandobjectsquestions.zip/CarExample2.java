public class CarExample2
{
    public static void main(String[] args)
    {
        Car supercar = new Car(0, 8);
        int supernum = 8;
        tripleGas(supercar);
        tripleValue(supernum);
        System.out.print("Gas in supercar: ");
        System.out.println(supercar.getGas());
        System.out.print("Value of supernum: ");
        System.out.println(supernum);
    }
    public static void tripleGas(Car c)
    {
        double currentGas = c.getGas();
        c.setGas(3 * currentGas);
    }
    public static void tripleValue(int value)
    {
        int newValue = value * 3;
        value = newValue;
    }
}