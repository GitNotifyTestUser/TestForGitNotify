public class Car
{
    private double position;
    private double milesDriven;
    private double gas;

    /**
     * This constructor creates a Car object
     * @initialPosition - the car�s initial position. The location, in miles, at which it starts
     * @initialGas - The amount of gas initially in the car
    */
    public Car(double initialPosition, double initialGas)
    {
        position = initialPosition;
        gas = initialGas;
    }
    public void travel(double distanceTraveled)
    {
    	position += distanceTraveled;
        milesDriven += Math.abs(distanceTraveled);
        gas -= Math.abs(distanceTraveled) / 32;
        if(gas <= 0)
            System.out.println("You ran out of gas!");
        //Math.abs(distanceTraveled) finds the absolute value.
    }
    public void refuelGas()
    {
        gas = 30;
    }
    public void setGas(double newGas) //This method is only used in a tier 5 problem
    {
        gas = newGas;
    }
    public double getPosition()
    {
        return position;
    }
    public double getMiles()
    {
        return milesDriven;
    }
    public double getGas()
    {
        return gas;
    }
}