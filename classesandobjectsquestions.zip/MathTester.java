public class MathTester
{
    public static void main(String[] args)
    {
        int a = doSomethingElse(3, 6);
        int b = doSomething(a, 2);
        System.out.println(b);
    }
    public static int doSomething(int x, int y)
    {
        return (x + (y * y) + 1) / 2;
    }
    public static int doSomethingElse(int x, int y)
    {
        int sum = 0;
        while(x < y)
        {
            sum += (x * y);
            x++;
        }
        return sum;
    }
}