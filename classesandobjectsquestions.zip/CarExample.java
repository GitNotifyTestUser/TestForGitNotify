public class CarExample
{
    public static void main(String[] args)
    {
        Car mycar = new Car(100, 29);
        Car yourcar = new Car(23, 24);
        System.out.println(mycar.getPosition());
        mycar = new Car(23, 25);
        yourcar = mycar;
        yourcar.travel(120);
        mycar.refuelGas();
        System.out.println(mycar.getPosition());
        System.out.println(mycar.getGas());
        System.out.println(yourcar.getPosition());
        System.out.println(yourcar.getGas());
    }
}