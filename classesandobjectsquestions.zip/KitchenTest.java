public class KitchenTest
{
    public static void main(String[] args)
    {
        Kitchen k = new Kitchen(120);
        for(int i = 0; i < 14; i++)
            k.spillFood(5);
        k.spillFood(10);
        k.sprayChemicals();
        System.out.println(k.getNumRoaches());
    }
}