public class IfElseTest
{
    public static void main(String[] args)
    {
        int x = 6;
        if(x > 0)
            if(x > 7)
                System.out.println("x is greater than 7.");
        else
            System.out.println("x is negative.");
    }
}