public class Kitchen
{
    private int numRoaches;
    public Kitchen(int initNumRoaches)
    {
        numRoaches = initNumRoaches;
    }
    public void spillFood(int numParticles)
    {
        numRoaches += numParticles;
    }
    public void sprayChemicals()
    {
        numRoaches /= 10;
    }
    public int getNumRoaches()
    {
        return numRoaches;
    }
}