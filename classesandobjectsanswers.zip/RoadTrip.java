public class RoadTrip
{
    public static void main(String[] args)
    {
        Car car = new Car(0,7);
        car.travel(-4.5);
        car.refuelGas();
        car.travel(4.5);
        car.travel(213.8);
        car.travel(-20.2);
        car.travel(365.2);
       
        System.out.print("The car is ");
        System.out.print(car.getPosition());
        System.out.println(" miles away from home.");

        System.out.print("The amount of miles you traveled was ");
        System.out.print(car.getMiles());
        System.out.println(" miles.");
       
        System.out.print("The amount of gas left in the car is ");
        System.out.print(car.getGas());
        System.out.println(" gallons.");
    }
}