public class RoundOffTester
{
    public static void main(String[] args)
    {
        double sum = 0;
        for(int i = 1; i <= 1000000; i++)
        {
            sum += 0.1;
        }
        System.out.println(sum);
    }
}