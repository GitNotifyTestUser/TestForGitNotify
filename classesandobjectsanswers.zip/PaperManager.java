/*
* This class provides basic methods to manage amounts of paper
*/
public class PaperManager
{
		private int numberOfPaper; //Number of paper that this object has
		/**
		 *  The constructor initializes a paper manager object
		 *  and also sets the initial number of paper of the object to the passed
		 *  parameter
		 *  @numInitialPaper - the default number of paper the manager object has
		 */
		public PaperManager(int numInitialPaper)
		{
			numberOfPaper = numInitialPaper;
		}
		/**
		 * This method restocks the manager object�s paper
		 * by a given amount
		 * @amount - the amount to increase NumberOfPaper by
		 * @returns - nothing
		 */
		public void restockPaper(int amount)
		{
			numberOfPaper += amount;
		}

		/**
		 *   @sold - the amount to decrease NumberOfPaper by
		 */
		public void sellPaper(int sold)
		{
			numberOfPaper -= sold;
		}
		/**
		 * @returns - the current number of paper the company has
		 */
		public int getNumberOfPaper()
		{
			return numberOfPaper;
		}
}
