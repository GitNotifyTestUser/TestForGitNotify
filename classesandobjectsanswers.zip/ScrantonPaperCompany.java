/**
*  The code for main is below. It is in the same package as PaperManager
*  If you don�t know what �Scranton Paper Company� refers to, please watch �The Office�
*/
public class ScrantonPaperCompany
{
	public static void main(String[] args)
{
		//Create a new PaperManager object with 300 initial pages of paper
		PaperManager paper = new PaperManager(300);

		//Do some paper calculations -- add some, sell some, etc.
		paper.sellPaper(150);
		paper.restockPaper(300);
		paper.sellPaper(250);
		paper.sellPaper(50);
		paper.restockPaper(500);
		
		//Display the amount of paper in stock
		System.out.print("The amount of in stock: ");
		System.out.println(paper.getNumberOfPaper());
	}
}
